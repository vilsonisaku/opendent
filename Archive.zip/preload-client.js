const { contextBridge, ipcRenderer } = require('electron');

// Use synchronous IPC to get config from main process before page loads
// This is the only reliable method in both dev and packaged builds
let serverUrl = 'http://localhost:3747';
let serverKey = '';

try {
  const config = ipcRenderer.sendSync('config:getSync');
  if (config && config.serverUrl) {
    serverUrl = config.serverUrl;
    serverKey = config.serverKey || '';
    console.log('[preload-client] Config from main:', serverUrl);
  } else {
    console.warn('[preload-client] No config returned from main process');
  }
} catch(e) {
  console.error('[preload-client] IPC error:', e.message);
}

contextBridge.exposeInMainWorld('__clientConfig', {
  serverUrl,
  serverKey,
});

contextBridge.exposeInMainWorld('electronAPI', {
  resetSetup: () => ipcRenderer.invoke('config:reset'),
  getConfig:  () => ipcRenderer.invoke('config:get'),
});